package es.uniovi.ds.exam.main;

import java.io.*;

import es.uniovi.ds.exam.editor.Editor;

public class Main {

    public static void main(String[] args) throws IOException {

            Editor editor;
            
            // a) Interactive mode
            editor = new Editor(); 
            
            // b) Read commands from a script file (e.g., scripts/script1.txt, scripts/script2.txt...)
            //editor = new Editor(new FileReader("scripts/script1.txt")); 
            
            editor.run();
    }
}
