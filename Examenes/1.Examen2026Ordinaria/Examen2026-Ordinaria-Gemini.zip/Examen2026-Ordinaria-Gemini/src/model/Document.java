package es.uniovi.ds.exam.model;

import static java.nio.charset.StandardCharsets.*;
import static java.nio.file.Files.*;

import java.io.IOException;
import java.nio.file.Paths;

public class Document {

    private String content;

    /*
     * Creates and returns a new document from the contents of the given file.
     * If the file does not exist or cannot be read, an IOException is thrown.
     */
    public static Document fromFile(String fileName) throws IOException {
        byte[] bytes = readAllBytes(Paths.get(fileName));
        return new Document(new String(bytes, UTF_8));
    }

    public Document() {
        this("");
    }

    public Document(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return content;
    }
}