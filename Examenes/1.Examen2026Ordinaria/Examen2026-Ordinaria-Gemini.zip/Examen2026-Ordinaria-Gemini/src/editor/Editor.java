package es.uniovi.ds.exam.editor;

import java.io.*;
import java.util.*;

import es.uniovi.ds.exam.commands.Macro;
import es.uniovi.ds.exam.commands.Replace;
import es.uniovi.ds.exam.model.Document;
import es.uniovi.ds.exam.modes.DefinitionMode;
import es.uniovi.ds.exam.modes.Mode;
import es.uniovi.ds.exam.modes.NormalMode;
import es.uniovi.ds.exam.modes.RecordingMode;
import es.uniovi.ds.exam.commands.Delete;
import es.uniovi.ds.exam.commands.Insert;

public class Editor {
    private BufferedReader in;
    private boolean echo = false;
    private Document document;

    // --- Variables de Estado Iniciales (Flags caciques) ---
    private String currentMode = "NORMAL"; // Puede ser: "NORMAL", "RECORD", "DEFINE"
    private String currentMacroName = null;
    private List<String[]> currentMacroCommands = new ArrayList<>(); // Guarda los comandos crudos
    private Map<String, List<String[]>> savedMacros = new HashMap<>(); // Almacén de macros

    public Editor() { in = new BufferedReader(new InputStreamReader(System.in)); document = new Document(); }
    public Editor(Reader input, boolean echo) { in = new BufferedReader(input); document = new Document(); this.echo = echo; }

    public void run() throws IOException {
        System.out.println("====== EDITOR DE TEXTO ======");
        do {
            System.out.print("> ");
            String line = in.readLine();
            if (line == null) break;
            if (echo) System.out.println(line);
            
            String[] parts = line.split("\\s+");
            if (parts[0].equals("exit")) break;

            switch (parts[0]) {
                case "open" -> {
                    if (currentMode.equals("RECORD")) {
                        System.out.println(">>> Opening a file is not allowed while recording a macro");
                    } else if (currentMode.equals("DEFINE")) {
                        // Guarda la macro antes de abrir y sale a modo normal
                        savedMacros.put(currentMacroName, new ArrayList<>(currentMacroCommands));
                        document = Document.fromFile(parts[1]);
                        currentMode = "NORMAL";
                    } else {
                        document = Document.fromFile(parts[1]);
                    }
                }
                case "insert" -> {
                    String text = String.join(" ", Arrays.copyOfRange(parts, 1, parts.length));
                    if (currentMode.equals("NORMAL")) {
                        document.setContent(document.getContent() + text + " ");
                    } else if (currentMode.equals("RECORD")) {
                        document.setContent(document.getContent() + text + " ");
                        currentMacroCommands.add(parts); // Lo graba
                    } else if (currentMode.equals("DEFINE")) {
                        currentMacroCommands.add(parts); // Solo lo graba
                    }
                }
                case "delete" -> {
                    if (currentMode.equals("NORMAL") || currentMode.equals("RECORD")) {
                        int lastSpace = document.getContent().trim().lastIndexOf(" ");
                        if (lastSpace == -1) document.setContent("");
                        else document.setContent(document.getContent().substring(0, lastSpace + 1));
                    }
                    if (currentMode.equals("RECORD") || currentMode.equals("DEFINE")) {
                        currentMacroCommands.add(parts);
                    }
                }
                case "replace" -> {
                    if (currentMode.equals("NORMAL") || currentMode.equals("RECORD")) {
                        document.setContent(document.getContent().replaceAll(Pattern.quote(parts[1]), parts[2]));
                    }
                    if (currentMode.equals("RECORD") || currentMode.equals("DEFINE")) {
                        currentMacroCommands.add(parts);
                    }
                }
                case "record" -> {
                    if (currentMode.equals("RECORD")) {
                        System.out.println("A macro is already being recorded");
                    } else {
                        currentMode = "RECORD";
                        currentMacroName = parts[1];
                        currentMacroCommands = new ArrayList<>();
                    }
                }
                case "define" -> {
                    if (currentMode.equals("DEFINE")) {
                        System.out.println("A macro is already being defined");
                    } else {
                        currentMode = "DEFINE";
                        currentMacroName = parts[1];
                        currentMacroCommands = new ArrayList<>();
                    }
                }
                case "stop" -> {
                    if (!currentMode.equals("NORMAL")) {
                        savedMacros.put(currentMacroName, currentMacroCommands);
                        currentMode = "NORMAL";
                    }
                }
                case "play" -> {
                    List<String[]> macroToPlay = savedMacros.get(parts[1]);
                    if (macroToPlay != null) {
                        // Ejecutar secuencialmente de forma síncrona
                        for (String[] cmd : macroToPlay) {
                            // ¡Peligro! Aquí se duplicaría recursivamente toda la lógica del switch principal
                            ejecutarComandoInterno(cmd); 
                        }
                    }
                }
                default -> System.err.println("Unknown command");
            }
            System.out.println(document.getContent() + "\n");
        } while (true);
    }

    // Método auxiliar privado inventado para lidiar con el desastre del "play"
    private void ejecutarComandoInterno(String[] cmdParts) throws IOException {
        // Imagina repetir los trozos del switch aquí dentro... una pesadilla.
        if (cmdParts[0].equals("insert")) {
            String text = String.join(" ", Arrays.copyOfRange(cmdParts, 1, cmdParts.length));
            if (currentMode.equals("NORMAL") || currentMode.equals("RECORD")) {
                document.setContent(document.getContent() + text + " ");
            }
            if (currentMode.equals("RECORD") || currentMode.equals("DEFINE")) {
                currentMacroCommands.add(cmdParts);
            }
        }
        // ... etc
    }
}